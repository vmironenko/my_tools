#!/usr/bin/perl

$NOAD = 55; # % from 100

print "Content-type:text/html\n\n";
#print <<EndOfHTML;
#<html><head><title>Perl Environment Variables</title></head>
#<body>
#<h1>Perl Environment Variables</h1>
#EndOfHTML

if (int(rand(100)) <= $NOAD ) {

#<?xml version="1.0" encoding="UTF-8"?>
#<!DOCTYPE PLACEIQ_AD_RESPONSE SYSTEM "http://ads.placeiq.com/2/ad/placeiq_no_ad_response.dtd">
print '<PLACEIQ>
    <NOAD></NOAD>
</PLACEIQ>
';
} else {
#<?xml version="1.0" encoding="UTF-8"?>
#<!DOCTYPE PLACEIQ_AD_RESPONSE SYSTEM "http://ads.placeiq.com/2/ad/placeiq_no_ad_response.dtd">
print '<PLACEIQ>
<AD>
<CONTENT><![CDATA[<div class=\"piq_creative\">
<a href=\"http://adclick.g.doubleclick.net/aclk?sa=L&ai=BlAuGrgbZUuzmH-bvyAP71IC4DLqbu8cDAAAAEAEgquv7HjgAWILN6btjYISV7YXwHboBCWdmcF9pbWFnZcgBCcACAuACAOoCHjUxMDI0MjkwL1BsYWNlSVFfdGVzdF8xMDBfZmlsbPgCgdIegAMBkAP0CJgDpAOoAwHgBAGgBh8&num=0&sig=AOD64_1vzkdN05MJNj2WmSw0PX8_c_sPsA&client=ca-pub-9004609665008229&adurl=http://www.placeiq.com\"><img width=\"320\" height=\"50\" border=\"0\" src=\"http://pagead2.googlesyndication.com/pagead/imgad?id=CICAgKDjgbaK1AEQARgBMgh8bsKtyeCG3Q\"/></a>
<img src=\"http://pubads.g.doubleclick.net/pagead/adview?ai=BlAuGrgbZUuzmH-bvyAP71IC4DLqbu8cDAAAAEAEgquv7HjgAWILN6btjYISV7YXwHboBCWdmcF9pbWFnZcgBCcACAuACAOoCHjUxMDI0MjkwL1BsYWNlSVFfdGVzdF8xMDBfZmlsbPgCgdIegAMBkAP0CJgDpAOoAwHgBAGgBh8&sigh=cejQ9SBV2i4&template_id=10024570&adurl=http://t1.pub.placeiq.com/tracking_pixel.gif?LA=${PIQ_LT}&LO=${PIQ_LG}&AP=DFP&AU=${PIQ_AU}&PT=${PT_ID}&OI=${PIQ_OI}&LI=${PIQ_LI}&CC=${PIQ_CC}&RI=${PIQ_REQID}&IP=${USER_IP}&DM=${PIQ_DM}&DS=${PIQ_DS}&DI=${PIQ_DI}&UM=${PIQ_UM}&UO=${PIQ_UO}\" width=\"0\" height=\"0\" border=\"0\">
</div>]]></CONTENT>
<NETWORK>50024410</NETWORK>
<ORDERID>119462530</ORDERID>
<LINEITEMID>48861370</LINEITEMID>
<CREATIVEID>26700572290</CREATIVEID>
<CLICKTHRU><![CDATA[http://adclick.g.doubleclick.net/aclk?sa=L&ai=BlAuGrgbZUuzmH-bvyAP71IC4DLqbu8cDAAAAEAEgquv7HjgAWILN6btjYISV7YXwHboBCWdmcF9pbWFnZcgBCcACAuACAOoCHjUxMDI0MjkwL1BsYWNlSVFfdGVzdF8xMDBfZmlsbPgCgdIegAMBkAP0CJgDpAOoAwHgBAGgBh8&num=0&sig=AOD64_1vzkdN05MJNj2WmSw0PX8_c_sPsA&client=ca-pub-9004609665008229&adurl=]]></CLICKTHRU>
<ADTYPE>STG</ADTYPE>
<EXTENSIONS>
    <EXTENSION type="openrtb">
        <PRICE>0.80</PRICE>
        <IURL>http://pagead2.googlesyndication.com/pagead/imgad?id=CICAgKDjy4qHPxABGAEyCCUCWCVzdoMT</IURL>
        <ADOMAIN>placeiq.com</ADOMAIN>
        <CRTYPE>Image Ad</CRTYPE>
    </EXTENSION>
</EXTENSIONS>
</AD>
</PLACEIQ>
';

}
