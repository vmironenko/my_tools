#!/usr/bin/perl

use FCGI;
use FCGI::ProcManager;

use Socket;
use POSIX qw(setsid);

require 'syscall.ph';

&daemonize;

$ENV{PERL_SIGNALS} = 'unsafe';
#this keeps the program alive or something after exec'ing perl scripts
END() { } BEGIN() { }
*CORE::GLOBAL::exit = sub { die "fakeexit\nrc=".shift()."\n"; }; 
eval q{exit}; 
if ($@) { 
	exit unless $@ =~ /^fakeexit/; 
};

&main;

sub daemonize() {
    chdir '/'                 or die "Can't chdir to /: $!";
    defined(my $pid = fork)   or die "Can't fork: $!";
    exit if $pid;
    setsid                    or die "Can't start a new session: $!";
    umask 0;
}

sub main {
#	$socket = FCGI::OpenSocket( "/var/run/cgiwrap-dispatch.sock", 10 );
#        $socket = FCGI::OpenSocket( "127.0.0.1:8999", 10 ); #use IP sockets
#        $request = FCGI::Request( \*STDIN, \*STDOUT, \*STDERR, \%req_params, $socket );
#        if ($request) { request_loop()};
#            FCGI::CloseSocket( $socket );
  $proc_manager = FCGI::ProcManager->new( {n_processes => 5} );
    $socket = FCGI::OpenSocket( "/var/run/cgiwrap-dispatch.sock", 10 ); #use UNIX sockets - user running this script must have w access to the 'nginx' folder!!
  chmod 0666,"/var/run/cgiwrap-dispatch.sock";
      $request =  FCGI::Request( \*STDIN, \*STDOUT, \*STDERR, \%req_params, $socket,  &FCGI::FAIL_ACCEPT_ON_INTR );
        $proc_manager->pm_manage();
          if ($request) { request_loop() };
            FCGI::CloseSocket($socket);
            
}


sub dfp {
$NOAD = 55; # % from 100

print "Content-type:text/html\n\n";

if (int(rand(100)) <= $NOAD ) {

print '<PLACEIQ>
    <NOAD></NOAD>
</PLACEIQ>
';
} else {
print '<PLACEIQ>
<AD>
<CONTENT><![CDATA[<div class=\"piq_creative\">
<a href=\"http://adclick.g.doubleclick.net/aclk?sa=L&ai=BlAuGrgbZUuzmH-bvyAP71IC4DLqbu8cDAAAAEAEgquv7HjgAWILN6btjYISV7YXwHboBCWdmcF9pbWFnZcgBCcACAuACAOoCHjUxMDI0MjkwL1BsYWNlSVFfdGVzdF8xMDBfZmlsbPgCgdIegAMBkAP0CJgDpAOoAwHgBAGgBh8&num=0&sig=AOD64_1vzkdN05MJNj2WmSw0PX8_c_sPsA&client=ca-pub-9004609665008229&adurl=http://www.placeiq.com\"><img width=\"320\" height=\"50\" border=\"0\" src=\"http://pagead2.googlesyndication.com/pagead/imgad?id=CICAgKDjgbaK1AEQARgBMgh8bsKtyeCG3Q\"/></a>
<img src=\"http://pubads.g.doubleclick.net/pagead/adview?ai=BlAuGrgbZUuzmH-bvyAP71IC4DLqbu8cDAAAAEAEgquv7HjgAWILN6btjYISV7YXwHboBCWdmcF9pbWFnZcgBCcACAuACAOoCHjUxMDI0MjkwL1BsYWNlSVFfdGVzdF8xMDBfZmlsbPgCgdIegAMBkAP0CJgDpAOoAwHgBAGgBh8&sigh=cejQ9SBV2i4&template_id=10024570&adurl=http://t1.pub.placeiq.com/tracking_pixel.gif?LA=${PIQ_LT}&LO=${PIQ_LG}&AP=DFP&AU=${PIQ_AU}&PT=${PT_ID}&OI=${PIQ_OI}&LI=${PIQ_LI}&CC=${PIQ_CC}&RI=${PIQ_REQID}&IP=${USER_IP}&DM=${PIQ_DM}&DS=${PIQ_DS}&DI=${PIQ_DI}&UM=${PIQ_UM}&UO=${PIQ_UO}\" width=\"0\" height=\"0\" border=\"0\">
</div>]]></CONTENT>
<NETWORK>50024410</NETWORK>
<ORDERID>119462530</ORDERID>
<LINEITEMID>48861370</LINEITEMID>
<CREATIVEID>26700572290</CREATIVEID>
<CLICKTHRU><![CDATA[http://adclick.g.doubleclick.net/aclk?sa=L&ai=BlAuGrgbZUuzmH-bvyAP71IC4DLqbu8cDAAAAEAEgquv7HjgAWILN6btjYISV7YXwHboBCWdmcF9pbWFnZcgBCcACAuACAOoCHjUxMDI0MjkwL1BsYWNlSVFfdGVzdF8xMDBfZmlsbPgCgdIegAMBkAP0CJgDpAOoAwHgBAGgBh8&num=0&sig=AOD64_1vzkdN05MJNj2WmSw0PX8_c_sPsA&client=ca-pub-9004609665008229&adurl=]]></CLICKTHRU>
<ADTYPE>STG</ADTYPE>
<EXTENSIONS>
    <EXTENSION type=\"openrtb\">
        <PRICE>0.80</PRICE>
        <IURL>http://pagead2.googlesyndication.com/pagead/imgad?id=CICAgKDjy4qHPxABGAEyCCUCWCVzdoMT</IURL>
        <ADOMAIN>placeiq.com</ADOMAIN>
        <CRTYPE>Image Ad</CRTYPE>
    </EXTENSION>
</EXTENSIONS>
</AD>
</PLACEIQ>
';

}
}



sub request_loop {
        while( $request->Accept() >= 0 ) {
            
           #processing any STDIN input from WebServer (for CGI-POST actions)
           $stdin_passthrough ='';
           $req_len = 0 + $req_params{'CONTENT_LENGTH'};
           if (($req_params{'REQUEST_METHOD'} eq 'POST') && ($req_len != 0) ){ 
                my $bytes_read = 0;
                while ($bytes_read < $req_len) {
                        my $data = '';
                        my $bytes = read(STDIN, $data, ($req_len - $bytes_read));
                        last if ($bytes == 0 || !defined($bytes));
                        $stdin_passthrough .= $data;
                        $bytes_read += $bytes;
                }
            }

            #running the cgi app
            if ( (-x $req_params{SCRIPT_FILENAME}) &&  #can I execute this?
                 (-s $req_params{SCRIPT_FILENAME}) &&  #Is this file empty?
                 (-r $req_params{SCRIPT_FILENAME})     #can I read this file?
            ){
		pipe(CHILD_RD, PARENT_WR);
		my $pid = open(KID_TO_READ, "-|");
		unless(defined($pid)) {
			print("Content-type: text/plain\r\n\r\n");
                        print "Error: CGI app returned no output - ";
                        print "Executing $req_params{SCRIPT_FILENAME} failed !\n";
			next;
		}
		if ($pid > 0) {
			close(CHILD_RD);
			print PARENT_WR $stdin_passthrough;
			close(PARENT_WR);

			while(my $s = <KID_TO_READ>) { print $s; }
			close KID_TO_READ;
			waitpid($pid, 0);
		} else {
	                foreach $key ( keys %req_params){
        	           $ENV{$key} = $req_params{$key};
                	}
        	        # cd to the script's local directory
	                if ($req_params{SCRIPT_FILENAME} =~ /^(.*)\/[^\/]+$/) {
                        	chdir $1;
                	}

			close(PARENT_WR);
			close(STDIN);
			#fcntl(CHILD_RD, F_DUPFD, 0);
			syscall(&SYS_dup2, fileno(CHILD_RD), 0);
			#open(STDIN, "<&CHILD_RD");
#			exec($req_params{SCRIPT_FILENAME});
		        dfp();
			die("exec failed");
		}
            } 
            else {
                print("Content-type: text/plain\r\n\r\n");
                print "Error: No such CGI app - $req_params{SCRIPT_FILENAME} may not ";
                print "exist or is not executable by this process.\n";
            }

        }
}
