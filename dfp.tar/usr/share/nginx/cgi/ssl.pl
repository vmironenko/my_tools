#!/usr/bin/perl

use warnings;
use Socket;
use POSIX qw(setsid);
use LWP::UserAgent;
use Net::SSL;
#use IO::Socket::SSL;


 # simple client
# my $cl = IO::Socket::SSL->new('10.1.43.28:4343');
# print $cl "GET / HTTP/1.0\r\n\r\n";
# print <$cl>;

my $ua = LWP::UserAgent->new( ssl_opts => { verify_hostname => 0 }, );
my $req = GET 'https://github.com';
my $res = $ua->request($req);
if ($res->is_success) {
    print $res->content;
    } else {
        print $res->status_line . "\n";
}